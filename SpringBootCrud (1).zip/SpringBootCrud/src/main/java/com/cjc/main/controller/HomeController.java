package com.cjc.main.controller;

import javax.rmi.CORBA.Stub;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cjc.main.model.Student;
import com.cjc.main.service.HomeService;

@Controller
public class HomeController
{

	@Autowired
	HomeService hs;
	
	
	@RequestMapping("/")
	public String prelogin()
	{
		return "login";
	}
	
	@RequestMapping("/registration")
	public String preRegister()
	{
		return "registration";
	}
	
	@RequestMapping("/reg")
	public String RegData(@ModelAttribute Student st)
	{
		hs.saveData(st);
		return "login";
	}
	
	@RequestMapping("/login")
	public String loginCheck(@RequestParam("uname") String un,@RequestParam("password") String ps,Model m)
	{
		
		hs.logincheck(un,ps);
		
		Iterable list=hs.displayAllData();
		m.addAttribute("data", list);
		
		return "success";
	}
	
	
	
	
	
}
